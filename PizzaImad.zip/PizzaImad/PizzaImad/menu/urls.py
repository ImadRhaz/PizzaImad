from django.urls import path
from . import views

app_name = 'menu' #pour que le lien de voir le menu dans index.html de main
                  # sache de qu'elle index en parle
urlpatterns = [
    path('',views.index,name="index"),
]
