from django import forms
from .models import Pizza

class PizzaForm(forms.ModelForm):
    class Meta:
        model=Pizza
        fields=['nom','ingredients','prix','vegitarien']

class PizzaSearchForm(forms.Form):
    search_query=forms.CharField(max_length=100,required=False)