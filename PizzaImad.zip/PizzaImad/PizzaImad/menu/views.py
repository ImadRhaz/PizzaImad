from django.shortcuts import render
from .models import Pizza
from .forms import PizzaSearchForm

def index(request):
    pizzas = Pizza.objects.all()
    search_form = PizzaSearchForm(request.GET)

    if search_form.is_valid():
        search_query = search_form.cleaned_data.get('search_query')
        if search_query:
            search_results = Pizza.objects.filter(nom__icontains=search_query)
            pizzas = list(search_results) + [pizza for pizza in pizzas if pizza not in search_results]

    return render(request, 'menu/index.html', {'pizzas': pizzas, 'search_form': search_form})
